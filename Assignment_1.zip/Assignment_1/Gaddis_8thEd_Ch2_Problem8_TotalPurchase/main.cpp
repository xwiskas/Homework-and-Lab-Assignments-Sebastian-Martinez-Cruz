/* 
 * File:   main.cpp
 * Author: Sebastian Martinez Cruz
 * Created on June 23, 2022, 3:18 pm
 * Purpose: C++ Template - To be used in all future assignments 
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Mathematical/Physics/Conversions, Higher dimensioned arrays

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables 
    float it1, //Item number 1
          it2,//Item number 2
          it3,//Item number 3
          it4,//Item number 4
          it5;//Item number 5
            
    float subtotal,//Total of items prior to tax
              total, //Total of all items
              tax,//the tax on product 
             ptax;//percent of the tax
    //Initialize Variables
            it1=15.95;
            it2=24.95;
            it3=6.95;
            it4=12.95;
            it5=3.95;
            ptax=0.07;
    //Map inputs to outputs -> The Process
    subtotal=it1+it2+it3+it4+it5;
    tax=subtotal*ptax;
    total=tax+subtotal;
    //Display Results
    cout<< "Price of first item "<<it1<<endl;
    cout<< "Price of second item "<<it2<<endl;
    cout<< "Price of third item "<<it3<<endl;
    cout<< "Price of fourth item "<<it4<<endl;
    cout<< "Price of fifth item "<<it5<<endl;
    
    cout <<"Subtotal = " << subtotal << endl;
    cout <<"Tax = " << ptax << endl;
    cout <<"Total = " << total<< endl;
    //Exit stage right
    return 0;
}

