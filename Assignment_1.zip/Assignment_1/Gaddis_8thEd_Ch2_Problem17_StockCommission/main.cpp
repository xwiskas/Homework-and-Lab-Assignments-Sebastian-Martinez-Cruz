/* 
 * File:   main.cpp
 * Author: Sebastian Martinez Cruz
 * Created on June 22, 2022, 9:49 AM
 * Purpose: C++ Template - To be used in all future assignments 
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Mathematical/Physics/Conversions, Higher dimensioned arrays

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables 
    float stck, //the number of shares of stock
        priceS,// price per share 
        pcom,// percent of commission 
           stockprice,// price for the stock alone
           amntcom,// amount of commission 
           totalamnt;// total amount paid 
    //Initialize Variables
    
    stck=750, //number of shares bought 
    priceS=35, //price of the stock is 35 
    pcom=0.2 ;//percent of the commission
    
  
    //Map inputs to outputs -> The Process
    
    stockprice=stck*priceS ;        
    amntcom= pcom*stockprice ;
    totalamnt=stockprice+amntcom;
            
            
    //Display Results
    
    cout<<" Total amount payed for the stocks: $"<<stockprice<< endl;
    cout<<"Amount of commission: $"<<amntcom<< endl;
    cout<<"Total amount payed: $"<<totalamnt<< endl;
    
    
    
    //Exit stage right
    return 0;
}

