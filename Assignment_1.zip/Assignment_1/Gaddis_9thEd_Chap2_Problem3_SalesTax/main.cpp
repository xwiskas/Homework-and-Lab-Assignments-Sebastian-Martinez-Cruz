/* 
 * File:   main.cpp
 * Author: Sebastian Martinez Cruz
 * Created on June 28, 2022, 1:47 PM
 * Purpose: Sales Tax
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants
//Mathematical/Physics/Conversions, Higher dimensioned arrays

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables 
    float Purchase,//Amount of Purchase
            sTax,//State Tax
            cTax,//Country Tax
            total,//Total sales tax
            totalsTax,//total after state tax
            totalcTax;//total after country tax
    
    //Initialize Variables
    
     Purchase=95.00,
            sTax=0.04,
            cTax=0.02;
    
     //Map inputs to outputs -> The Process
    
    totalsTax=Purchase*sTax; //Amount after state tax
    totalcTax=Purchase*cTax; //Amount after country tax
    total=Purchase+totalsTax+totalcTax;
    
    
    
    //Display Results
    cout<<fixed<<setprecision(2)<<showpoint;
    cout<<"Subtotal             =$" <<Purchase<<endl;
      cout<<"State tax of "; cout<< sTax<<"%" "   = $" <<totalsTax<<endl;
    cout<<"Country tax of "; cout<< cTax<<"%" " = $"<<totalcTax<<endl;
    cout<<"Total                = $"<<total<<endl;        
    //Exit stage right
    return 0;
}

