/* 
 * File:   main.cpp
 * Author: Sebastian Martinez Cruz
 * Created on June 28, 2022, 3:07 PM
 * Purpose: Restaurant Bill
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants
//Mathematical/Physics/Conversions, Higher dimensioned arrays

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables 
   
    float tax, //Tax 
            taxamount,//Amount of tax
            charge,//Charge for the meal
          tip, //Tip in percent
            tipamount,//Amount of tip 
            subtotal,
            finalt,
            total;//Total after tax and tip
 
    //Initialize Variables
    tax=0.0675;
    charge=88.67;
    tip=0.20;
    
    //Map inputs to outputs -> The Process
    
    taxamount=tax*charge;//the amount of money bc of tax
    total=taxamount+charge;//the amount with tax add3ed to the price
    subtotal=tip*total;//the amount of tip to be added
    finalt=total+subtotal;//final total        
    //Display Results
    cout<<fixed<<setprecision(2)<<showpoint;
    cout<<"Meal cost:  $"<<charge<<endl;
    cout<<"Tax Amount: $"<<taxamount<<endl;
    cout<<"Tip amount: $"<<subtotal<<endl;
    cout<<"Total bill: $"<<finalt<<endl;
    //Exit stage right
    return 0;
}

