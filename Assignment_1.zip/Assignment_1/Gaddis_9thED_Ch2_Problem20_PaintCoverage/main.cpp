/* 
 * File:   main.cpp
 * Author: Sebastian Martinez Cruz
 * Created on June 24, 2022, 3:00 PM
 * Purpose: Paint Coverage
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Mathematical/Physics/Conversions, Higher dimensioned arrays

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables 
    float pCover,//Coverage of a gallon of paint in ft^2
         fHeight,//Fence height in ft 
            fLenght;//Length of the fence
    int nGals; //Number of gallons required
    
    //Initialize Variables
    pCover=3.4e2f;
    fHeight=6.0e0f;
    fLenght=1.0e2f;
    
    
    //Map inputs to outputs -> The Process
            float srfA=fHeight*fLenght;
    float sCover=2*2*srfA;
    nGals=sCover/pCover+1;
            
    //Display Results
    
    cout<< "Fence height = "<<fHeight<< " feet"<<endl;
    cout<< "Fence length = "<<fLenght<< " feet"<<endl;
    cout<< "Paint coverage = "<<pCover<<" feet^2"<<endl;
    cout<<" Number of gallons of paint required = "<<nGals<<" gallons"<<endl;
    //Exit stage right
    return 0;
}

