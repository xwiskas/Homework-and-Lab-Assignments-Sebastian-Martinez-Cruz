/* 
 * File:   main.cpp
 * Author: Sebastian Martinez Cruz
 * Created on June 23, 2022, 5:27 PM
 * Purpose: CircuitBoardPractice
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Mathematical/Physics/Conversions, Higher dimensioned arrays

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables 
    float pProfit,//Percent of profit
          priceB,//price of the board
           Profit, //total profit
            sellProfit;//= the selling price
    
    //Initialize Variables
            pProfit=.35,
            priceB=14.95;
            
            
    //Map inputs to outputs -> The Process
    Profit=pProfit*priceB;//This will calculate the profit of selling a circuit board
    sellProfit=Profit+priceB;//This will calculate the selling price
                    
    //Display Results
    cout<<"The selling price of a circuit board is "<<sellProfit<< endl;
   
    //Exit stage right
    return 0;
}

