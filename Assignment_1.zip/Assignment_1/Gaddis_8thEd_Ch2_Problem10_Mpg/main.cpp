/* 
 * File:   main.cpp
 * Author: Sebastian Martinez Cruz
 * Created on June 22, 2022, 9:49 AM
 * Purpose: C++ Template - To be used in all future assignments 
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Mathematical/Physics/Conversions, Higher dimensioned arrays

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables 
    int gallons,//How many gallons it can hold
         miles,//How much miles it can travel
         mpg;//Miles per gallon
    
    //Initialize Variables
    gallons=15;
            miles=375;
            
    //Map inputs to outputs -> The Process
            mpg=miles/gallons;
    //Display Results
            cout<< "The car's miles per gallon rate is " <<mpg<< endl;
    //Exit stage right
    return 0;
}

