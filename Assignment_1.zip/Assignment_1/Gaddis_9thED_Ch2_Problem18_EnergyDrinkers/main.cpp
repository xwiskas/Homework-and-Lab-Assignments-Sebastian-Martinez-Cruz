/* 
 * File:   main.cpp
 * Author: Sebastian Martinez Cruz
 * Created on June 24, 2022, 3:17 pM
 * Purpose: Energy Drinkers
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Mathematical/Physics/Conversions, Higher dimensioned arrays
const unsigned char PERCENT=100;//Conversion to percentage 
//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables 
    unsigned short
    
            nEnergy,//Number of energy drinkers
            cSur,//Customers surveyed
            nCitrus;//Number of citrus drinkers
    
    unsigned char pEnergy,//Percentage of energy drinkers
                  pCd;//Percentage of citrus drinkers
                  
    //Initialize Variables
    
            cSur=16500;
            pEnergy=15;
            pCd=58;
                   
    //Map inputs to outputs -> The Process
    
            nEnergy=cSur*pEnergy/PERCENT;
            nCitrus=nEnergy*pCd/PERCENT;
            
            
    //Display Results
    
    cout<<"Number of customers that use energy drinks = "  <<nEnergy<<endl;      
    cout<<"Number of customers that prefer citrus drinks = " <<nCitrus<<endl;    
            
    //Exit stage right
    return 0;
}

